.. testsetup:: *

   from pwn import *

:mod:`pwnlib.args` --- Magic Command-Line Arguments
=====================================================

.. automodule:: pwnlib.args
   :members:
