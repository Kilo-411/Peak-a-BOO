.. testsetup:: *

   from pwn import *
   from pwnlib.libcdb import *

:mod:`pwnlib.libcdb` --- Libc Database
===========================================

.. automodule:: pwnlib.libcdb
   :members:
