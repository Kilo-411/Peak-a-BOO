:mod:`pwnlib.shellcraft.common` --- Shellcode common to all architecture
========================================================================

.. automodule:: pwnlib.shellcraft.common
   :members:
