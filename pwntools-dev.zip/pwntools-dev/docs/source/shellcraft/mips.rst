.. testsetup:: *

   from pwn import *
   context.clear(arch='mips')

:mod:`pwnlib.shellcraft.mips` --- Shellcode for MIPS
===========================================================

:mod:`pwnlib.shellcraft.mips`
-----------------------------

.. automodule:: pwnlib.shellcraft.mips
   :members:

:mod:`pwnlib.shellcraft.mips.linux`
-----------------------------------

.. automodule:: pwnlib.shellcraft.mips.linux
   :members:
