.. testsetup:: *

   from pwn import *
   context.clear(arch='amd64')

:mod:`pwnlib.shellcraft.amd64` --- Shellcode for AMD64
===========================================================

:mod:`pwnlib.shellcraft.amd64`
---------------------------------------

.. automodule:: pwnlib.shellcraft.amd64
   :members:

:mod:`pwnlib.shellcraft.amd64.linux`
---------------------------------------

.. automodule:: pwnlib.shellcraft.amd64.linux
   :members:
