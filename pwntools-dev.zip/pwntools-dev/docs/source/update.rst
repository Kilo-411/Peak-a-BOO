.. testsetup:: *

   from pwn import *
   from pwnlib.update import *

:mod:`pwnlib.update` --- Updating Pwntools
===================================================

.. automodule:: pwnlib.update
   :members:
