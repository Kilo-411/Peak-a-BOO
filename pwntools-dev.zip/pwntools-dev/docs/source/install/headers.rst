Python Development Headers
-----------------------------

Some of pwntools' Python dependencies require native extensions (for example, Paramiko requires PyCrypto).

In order to build these native extensions, the development headers for Python must be installed.

Ubuntu
^^^^^^^^^^^^^^^^

.. code-block:: bash

    $ apt-get install python-dev

Mac OS X
^^^^^^^^^^^^^^^^

No action needed.