.. testsetup:: *

   from pwn import *

:mod:`pwnlib.rop.rop` --- Return Oriented Programming
==========================================================

.. automodule:: pwnlib.rop.rop
   :members:
