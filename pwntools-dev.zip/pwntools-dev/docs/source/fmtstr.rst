.. testsetup:: *

	from pwn import *
	import tempfile

:mod:`pwnlib.fmtstr` --- Format string bug exploitation tools
=============================================================

.. automodule:: pwnlib.fmtstr
   :members:
