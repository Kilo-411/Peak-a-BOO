.. testsetup:: *

   from pwn import *

:mod:`pwnlib.runner` --- Running Shellcode
===========================================

.. automodule:: pwnlib.runner
   :members:
