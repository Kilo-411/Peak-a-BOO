.. testsetup:: *

    from pwn import *

:mod:`pwnlib.memleak` --- Helper class for leaking memory
=========================================================

.. automodule:: pwnlib.memleak
    :members:
