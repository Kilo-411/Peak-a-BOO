.. testsetup:: *

   from pwnlib.useragents import *

:mod:`pwnlib.useragents` --- A database of useragent strings
============================================================

.. automodule:: pwnlib.useragents
   :members:
