.. testsetup:: *

   from pwn import *

:mod:`pwnlib.tubes.serialtube` --- Serial Ports
===========================================================

.. automodule:: pwnlib.tubes.serialtube

   .. autoclass:: pwnlib.tubes.serialtube.serialtube
      :members:
