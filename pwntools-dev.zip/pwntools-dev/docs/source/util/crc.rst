.. testsetup:: *

   from pwnlib.util.crc import *


:mod:`pwnlib.util.crc` --- Calculating CRC-sums
===============================================

.. automodule:: pwnlib.util.crc
   :members:
