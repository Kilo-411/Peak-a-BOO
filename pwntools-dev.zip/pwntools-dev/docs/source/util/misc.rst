.. testsetup:: *

   from pwnlib.util.misc import *
   import os, subprocess
   os.chdir("..")

:mod:`pwnlib.util.misc` --- We could not fit it any other place
===============================================================

.. automodule:: pwnlib.util.misc
   :members:
