from __future__ import absolute_import

from pwnlib.encoders.i386 import delta
from pwnlib.encoders.i386 import xor
