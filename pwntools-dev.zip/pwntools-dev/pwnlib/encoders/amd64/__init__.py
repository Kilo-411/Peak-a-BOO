from __future__ import absolute_import

from pwnlib.encoders.amd64 import delta
