#define __arm__
#define __ARM_EABI__ 1
#define __KERNEL__   1
#include <arm/syscalls.h>
#include <common.h>
