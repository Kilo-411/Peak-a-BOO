#define __s390x__
#include <s390x/syscalls.h>
#include <common.h>
