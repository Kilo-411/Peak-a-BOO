#define __arm__
#define __thumb__
#include <arm/syscalls.h>
#include <common.h>
