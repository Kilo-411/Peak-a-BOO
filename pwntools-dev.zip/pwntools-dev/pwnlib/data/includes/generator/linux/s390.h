#define __s390__
#include <s390/syscalls.h>
#include <common.h>
