#define __mips__
#include <mips/syscalls.h>
#include <common.h>
