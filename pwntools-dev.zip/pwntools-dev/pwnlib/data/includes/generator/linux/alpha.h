#define __alpha__
#include <alpha/syscalls.h>
#include <common.h>
