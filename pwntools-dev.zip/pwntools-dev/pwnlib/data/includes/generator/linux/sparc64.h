#define __sparc64__
#include <sparc64/syscalls.h>
#include <common.h>
