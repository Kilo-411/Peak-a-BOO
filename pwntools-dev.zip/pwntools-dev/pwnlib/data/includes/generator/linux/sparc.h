#define __sparc__
#include <sparc/syscalls.h>
#include <common.h>
