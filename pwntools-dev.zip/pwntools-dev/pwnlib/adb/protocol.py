"""
This file exists only for backward compatibility
"""
from pwnlib.protocols.adb import AdbClient
Client = AdbClient
