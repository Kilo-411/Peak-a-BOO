def merlin( counter):
	return r"\x31\xc0\x40\x74"+counter