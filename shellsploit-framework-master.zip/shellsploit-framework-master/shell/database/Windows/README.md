#Windows shellcodes will be work on both x86 / x86_x64



#Test OS's
      Windows XP/SP3 -x86
      Windows 7      -x64
      Windows 8.1    -x64
      Windows 10     -x64
