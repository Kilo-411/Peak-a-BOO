from shell import shellsploit

shellsploit.main()