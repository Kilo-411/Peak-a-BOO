#Shellsploit 
-------------

Shellsploit let's you generate customized shellcodes, backdoors, injectors for various operating system.
And let's you obfuscation every byte via encoders.



#StableVersion
---------------
    Still not exists stable version, because of too many file(any help would be great hehe).


#Dependences
-------------
    root$ sudo pip install capstone
    root$ sudo pip install readline(Not necessary for windows coz preinstalled in shellsploit)
    root$ sudo pip install pefile
    root$ sudo pip install colorama
    root$ sudo pip install pylzma


#Installation	
-------------
Pip works on both windows/nix machines without problem. Now you are ready to install:

    root$ python setup.py --s/ --setup install 
    root$ chmod +x shellsploit (if you are using windows just pass this step)
    root$ ./shellsploit

#Uninstallation
----------------
	root$ python setup.py --s/--setup uninstall


#I DONT WANT INSTALL THIS 
---------------------------

Then don't.You can use shellsploit without install.

	$root cd shellsploit-framework
	$root python shellsploit.py or python3 shellsploit.py


#Usage
-----

    usage: shellsploit  [-l] [-p] [-o] [-n]
    						[--host] [--port]


    optional arguments:
	  	   -l, --list 			Show  list of backdoors,shellcodes,encoders,injectors
	  	   -p, --payload 		Set payload for usage
	  	   -n, -nc 				Declare netcat for usage
	  	   --host				The connect/listen address
	  	   --port				The connect/listen port	

  	Inline arguments:

  		Main Menu:
			help           		Help menu
			os					Command directly ur computer
			use 				Select Module For Use
			clear				Clear the menu
			show modules    	Show Modules of Current Database
			show backdoors    	Show Backdoors of Current Database
			show injectors		Show Injectors(Shellcode,dll,so etc..)

		Shellcode Menu:
			back				Exit Current Module
			set 				Set Value Of Options To Modules
			ip					Get IP address(Requires net connection)
			os					Command directly ur computer
			clear				Clear the menu
			disas				Disassembly the shellcode(Support : x86/x64)
			whatisthis      	Learn which kind of shellcode it is
			iteration			Encoder iteration time
			generate 			Generate shellcode 
			output 				Save option to shellcode(txt,py,c,cpp,exe)
			show encoders		List all obfucscation encoders
			show options		Show Current Options Of Selected Module

		Injector Menu:
			set 				Set Value Of Options To Modules
			help 				Help menu
			back				Exit Current Module
			os  				Command directly ur computer
			pids				Get PID list of computer
			getpid				Get specific PID on list(Ex. getpid Python)


#Bugs
------

Please do not forget to report bugs! You can submit an issue, pull request, or even directly PM me through my email address.


#Screenshots
-------------

![alt tag](http://i.hizliresim.com/28XmmN.png)
![alt tag](http://i.hizliresim.com/7MrYVv.png)
![alt tag](http://i.hizliresim.com/g8NqXN.jpg)
![alt tag](http://i.hizliresim.com/W18pL2.png)
![alt tag](http://i.hizliresim.com/pBMNO0.png)
![alt tag](http://i.hizliresim.com/rZP6vV.png)
